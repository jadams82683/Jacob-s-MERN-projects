import React, {useState} from 'react';

const PersonCard = (props) => {
    const {firstName, lastName, initialAge, hairColor} = props;
    const [stateAge, setStateAge] = useState(initialAge);

    return (
        <div>
            <h2>
                Name: {lastName}, {firstName};
            </h2>
            <p>Age: {stateAge}</p>
            <p>Hair Color: {hairColor}</p>
            <button onClick={(event) => setStateAge(stateAge + 1)}>
                Birthday Button for {firstName} {lastName}
            </button>
        </div>
    );

};

export default PersonCard;
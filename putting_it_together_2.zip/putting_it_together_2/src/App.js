import logo from './logo.svg';
import './App.css';
import PersonCard from './components/PersonCard';

const peopleArr = [
  {
    firstName: "Wolfgang",
    lastName: "Mozart",
    initialAge: 35,
    hairColor: "brown",
  },
  {
    firstName: "Ludwig",
    lastName: "van Beethoven",
    initialAge: 56,
    hairColor: "black",
  },
  {
    firstName: "Franz",
    lastName: "Schubert",
    initialAge: 31,
    hairColor: "black",
  },
  {
    firstName: "Johann",
    lastName: "Bach",
    initialAge: 65,
    hairColor: "white",
  },
];

function App() {
  return (
    <div className="App">
      {peopleArr.map((personObj, index) => 
      <PersonCard
        key={index}
        firstName={personObj.firstName}
        lastName={personObj.lastName}
        age={personObj.initialAge}
        hairColor={personObj.hairColor}/>
      )}
    </div>
  );
}

export default App;

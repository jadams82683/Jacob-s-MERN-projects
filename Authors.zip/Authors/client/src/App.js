import React from 'react';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import CreateAuthor from './components/CreateAuthor';
import DisplayAuthors from './components/DisplayAuthors';
import UpdateAuthor from './components/UpdateAuthor';

function App() {
  return (
    <div className="App">
        <h1>Jacob's Favorite Authors</h1>
        <BrowserRouter>
            <Routes>
                <Route path = "/" element = {<DisplayAuthors/>}/>
                <Route path = "/new" element = {<CreateAuthor/>}/>
                <Route path = "/edit/:id" element = {<UpdateAuthor/>}/>
            </Routes>
        </BrowserRouter>
    </div>
  );
}

export default App;

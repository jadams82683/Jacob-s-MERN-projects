import React, {useEffect, useState} from 'react';
import axios from 'axios';
import {Link, useParams} from 'react-router-dom';

const UpdateAuthor = (props) => {
    const {id} = useParams();
    const [authorName, setAuthorName] = useState("");
    const [errors, setErrors] = useState({});
    const [authorNotFoundError, setAuthorNotFoundError] = useState("");
    console.log(id);

    useEffect(() => {
        axios.get(`http://localhost:8000/api/author/${id}`)
            .then((response) => {
                console.log(response.data);
                setAuthorName(response.data.name);
            })
            .catch((err) => {
                console.log(err.response);
                setAuthorNotFoundError(`Author not found using that ID number. Please try again.`);
            });
    }, []);

    const submitHandler = (event) => {
        event.preventDefault();

        axios.put(`http://localhost:8000/api/author/${id}`, {name: authorName})
        .then((response) => {
            console.log(response);
        })
        .catch((err) => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        });
    };

    return (
        <form onSubmit = {submitHandler}>
            {authorNotFoundError ? (
                <h2>{authorNotFoundError} <Link to = "/new">Click here to add a new author</Link></h2>
            ) : null}
            <Link to = "/">Go back to home page</Link>
            <div className = "form">
                <label htmlFor = "name">Author's Name</label>
                <input type = "text" id = "name" value = {authorName} onChange = {(e) => setAuthorName(e.target.value)}/>
                {errors.name ? <p>{errors.name.message}</p> : null}
            </div>
            <button type = "submit" className = "button">Submit new Author info</button>
        </form>
    );
};

export default UpdateAuthor;
import React, {useEffect, useState} from 'react';
import axios from 'axios';
import {Link} from 'react-router-dom';

const DisplayAuthors = () => {
    const [allAuthors, setAllAuthors] = useState([]);
    useEffect(() => {
        axios.get("http://localhost:8000/api/author")
        .then((response) => {
            console.log(response.data);
            setAllAuthors(response.data);
        })
        .catch((err) => {
            console.log(err.response);
        });
    }, []);

    const deleteHandler = (idFromBelow) => {
        axios.delete(`http://localhost:8000/api/author/${idFromBelow}`)
        .then((response) => {
            console.log("Yay! Author successfully deleted.");
            console.log(response);
            const filteredAuthors = allAuthors.filter((author) => {
                return author._id !== idFromBelow;
            });
            setAllAuthors(filteredAuthors);
        })
        .catch((err) => {
            console.log("Uh oh. We encountered an error.", err.reponse);
        });
    };

    return (
        <div className = "container">
            <div className = "row">
                <div className = "column">
                    <Link to = "/new">Add a new Author</Link>
                    <p className = "text">We have quotes by:</p>
                    <table className = "table">
                        <thead>
                            <tr>
                                <th scope = "col">Author</th>
                                <th scope = "col">Available Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {allAuthors.map((author, index) => {
                                return (
                                    <tr key = {index}>
                                        <td>{author.name}</td>
                                        <td>
                                            <Link to = {`/edit/${author._id}`}>
                                                <button className = "button">Edit Author</button>
                                            </Link>
                                            <button onClick = {() => deleteHandler(author._id)} className = "buttontwo">Delete Author</button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default DisplayAuthors;

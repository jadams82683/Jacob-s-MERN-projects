import React, {useState} from 'react';
import axios from 'axios';
import {Link, useNavigate} from 'react-router-dom';

const CreateAuthor = () => {
    const [name, setName] = useState("");
    const [errors, setErrors] = useState({});
    const navigate = useNavigate();
    
    const submitHandler = (event) => {
        event.preventDefault();
        axios.post("http://localhost:8000/api/author", {name})
        .then((response) => {
            console.log(response);
            navigate("/");
        })
        .catch((err) => {
            console.log(err.response.data.err.errors);
            setErrors(err.response.data.err.errors);
        });
    };

    return (
        <div className = "container">
            <div className = "row">
                <div className = "col2">
                    <Link to = "/">Back to Home Page</Link>
                    <form onSubmit = {submitHandler}>
                        <div className = "form">
                            <label htmlFor = "name">Name of Author</label>
                            <input type = "text" className = "control" value = {name} onChange = {(e) => setName(e.target.value)}/>
                            {errors.name ? <p>{errors.name.message}</p> : null}
                        </div>
                        <button className = "button" type="submit">Submit new Author</button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default CreateAuthor;
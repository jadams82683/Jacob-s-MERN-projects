import React, { useState } from 'react';

const Form = (props) => {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPw, setConfirmPw] = useState("");

    const createUser = (e) => {
        e.preventDefault();

        const newUser = {
            firstName: firstName, 
            lastName: lastName,
            email: email,
            password: password,
            confirmPw: confirmPw
        };
        setFirstName("");
        setLastName("");
        setEmail("");
        setPassword("");
        setConfirmPw("");
    };

    return (
        <div>
            <form onSubmit={ createUser }>
                <div class="input">
                    <label>First Name: </label>
                    <input type="text" onChange={ (e) => setFirstName(e.target.value) } value={firstName}/>
                </div>
                <div class="input">
                    <label>Last Name: </label>
                    <input type="tect" onChange={ (e) => setLastName(e.target.value)} value={lastName}/>
                </div>
                <div class="input">
                    <label>Email: </label>
                    <input type="email" onChange={ (e) => setEmail(e.target.value)} value={email}/>
                </div>
                <div class="input">
                    <label>Password: </label>
                    <input type="password" onChange={ (e) => setPassword(e.target.value)} value={password}/>
                </div>
                <div class="input">
                    <label>Confirm Password: </label>
                    <input type="password" onChange={ (e) => setConfirmPw(e.target.value)} value={confirmPw}/>
                </div>
                <input type="submit" value="Create User"/>
            </form>
            <h2>Your form data</h2>
            <p>First Name: {firstName}</p>
            <p>Last Name: {lastName}</p>
            <p>Email: {email}</p>
            <p>Password: {password}</p>
            <p>Confirm Password: {confirmPw}</p>
        </div>
    );
};

export default Form;
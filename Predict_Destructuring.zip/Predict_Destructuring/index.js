const cars = ['Tesla', 'Mercedes', 'Honda']
const [ randomCar ] = cars // randomCar = Tesla, because it's the only variable specified and thus is assigned to the virst item in 'cars' by default
const [ ,otherRandomCar ] = cars // otherRandomCar = 'Mercedes' because the comma skips over the first item, thus we go to the next one
//Predict the output
console.log(randomCar) // will log 'Tesla'
console.log(otherRandomCar) // will log 'Mercedes'

const employee = {
    name: 'Elon',
    age: 47,
    company: 'Tesla'
}
const { name: otherName } = employee; // otherName = Elon
//Predict the output
console.log(name); // because we're not specifying where 'name' comes from, it throws an error and thus the code stops running
console.log(otherName);

const person = {
    name: 'Phil Smith',
    age: 47,
    height: '6 feet'
}
const password = '12345';
const { password: hashedPassword } = person;//this won't work because the person object doesn't have a property called 'password'
//Predict the output
console.log(password); // logs '12345'
console.log(hashedPassword); // undefined - hashedPassword couldn't be assigned to anything

const numbers = [8, 2, 3, 5, 6, 1, 67, 12, 2];
const [,first] = numbers; //first is set to 2
const [,,,second] = numbers; //second is set to 5
const [,,,,,,,,third] = numbers;//third is set to 2
//Predict the output
console.log(first == second); // false; 2 is not equal to 5
console.log(first == third);//true; both are equal to 2

const lastTest = {
    key: 'value',
    secondKey: [1, 5, 1, 8, 3, 3]
}
const { key } = lastTest; //key variable is equal to 'value'
const { secondKey } = lastTest; //secondKey is equal to [1, 5, 1, 8, 3, 3]
const [ ,willThisWork] = secondKey; //willThisWork is assigned to 5
//Predict the output
console.log(key);//value
console.log(secondKey);//[1, 5, 1, 8, 3, 3]
console.log(secondKey[0]);//1
console.log(willThisWork);//5



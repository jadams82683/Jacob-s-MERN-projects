import logo from './logo.svg';
import './App.css';
import Tabs from './components/Tabs';
import Results from './components/Results';
import React, { useState } from 'react';

function App() {

  const allTabs = [
    {label: "Tab #1", content: "You just clicked on Tab #1!"},
    {label: "Tab #2", content: "You just clicked on Tab #2!"},
    {label: "Tab #3", content: "You just clicked on Tab #3!"},
    {label: "Tab #4", content: "You just clicked on Tab #4!"},
    {label: "Tab #5", content: "You just clicked on Tab #5!"},
  ];

  const [clickedIndex, setClickedIndex] = useState(0);
  const [tabArray, setTabArray] = useState(allTabs);

  return (
    <div className="App">
      <Tabs
        allTabs = {tabArray}
        currentIndex = {clickedIndex}
        setCurrentIndex = {setClickedIndex}/>
      <Results 
        everyTab = {tabArray}
        currentIndex = {clickedIndex}/>
    </div>
  );
}

export default App;

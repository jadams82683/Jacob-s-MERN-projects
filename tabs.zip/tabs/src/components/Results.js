import React, { useState } from 'react';

const Results = (props) => {

  const { everyTab, currentIndex } = props;

  return (
    <div>
      {everyTab[currentIndex].content}
    </div>
  );
};

export default Results;
import React, { useState } from 'react';

const Tabs = (props) => {

  const { allTabs, currentIndex, setCurrentIndex } = props; //tabArray is the array of tabs, currentIndex is the index of whichever has just been clicked on and keeps track of it

  const tabStyle = (index) => { // this determines which style to apply to which tab; 
    if (index === currentIndex) {
      return "selectedTab" //this is a selector that will apply the styles if the tab is selected
    }
    else {
      return "non-selectedTab" //this is a selector that will apply the styles if the tab isn't selected
    }
  }

  const setSelectedTab = (index) => {
    setCurrentIndex(index);
  }

  return (
    <div style={{ margin: "auto", width: "85%", textAlign: "left"}}>

      {/* we do not actually need to use content, but it MUST be there so we can get the index */}
      {
        allTabs.map((item, index) => (
          <div className={`tab ${ tabStyle(index) }`} onClick={(e) => setSelectedTab(index) }>
            { item.label }
          </div>
        ))
      }
    </div>
  )
};

export default Tabs;